package Core.Exception;

public class removeException extends RuntimeException {
    public removeException(String message) {
        super(message);
    }
}
