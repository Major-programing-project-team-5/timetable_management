package Core.Exception;

public class addException extends RuntimeException {
    public addException(String message) {
        super(message);
    }
}
