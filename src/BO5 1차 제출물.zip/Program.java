import Core.Views.OnloadProgram;

public class Program {
  public static void main(String[] args) {
        OnloadProgram onloadProgram = new OnloadProgram();
        onloadProgram.run();
    }


}